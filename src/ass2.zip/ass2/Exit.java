package ass2;

/**
 * used to check win condition if the player reaches the exit
 * @author gordon
 *
 */
public class Exit extends Entity{
	public Exit(int id) {
		super(id);
	}

	@Override
	public String toString() {
		return null;
	}
	
}
