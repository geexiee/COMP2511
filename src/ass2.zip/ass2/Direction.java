package ass2;

/**
 * Directions that entities can perform actions in
 * @author gordon
 *
 */
public enum Direction {
	NORTH,SOUTH,WEST,EAST
}
