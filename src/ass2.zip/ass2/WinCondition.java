package ass2;

/**
 * different conditions which can be fulfilled to win the game
 * @author gordon
 *
 */
public enum WinCondition {
	Boulder, Enemy, Treasure
}
