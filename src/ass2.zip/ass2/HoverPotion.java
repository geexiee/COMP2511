package ass2;

/**
 * allows player to move over pits without dying
 * @author gordon
 *
 */
public class HoverPotion extends Potion{
	public HoverPotion(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return null;
	}
}
