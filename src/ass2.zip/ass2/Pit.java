package ass2;

/**
 * entity which kills the player if the player walks over it
 * when a boulder is moved over the pit it becomes normal floor
 * @author gordon
 *
 */
public class Pit extends Entity{
	public Pit(int id) {
		super(id);
	}

	@Override
	public String toString() {
		return null;
	}
}
