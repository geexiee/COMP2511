package ass2;

/**
 * various states the the game can be in
 * @author gordon
 *
 */
public enum GameState {
	Paused, Win, Play, Quit, Menu, Lose, Design
}
