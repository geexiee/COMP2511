package ass2;

/**
 * Type of entity which can be collected by the player to win the game
 * @author gordon
 *
 */
public class Treasure extends Entity{
	public Treasure(int id) {
		super(id);
	}

	@Override
	public String toString() {
		return null;
	}
}
