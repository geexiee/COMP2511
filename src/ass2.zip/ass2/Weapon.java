package ass2;
/**
 * different types of weapons available
 * @author gordon
 *
 */
public enum Weapon {
	Bomb, Arrow, Sword, Move
}
