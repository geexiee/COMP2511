package ass2;

public class Boulder extends Obstacle{
	public Boulder(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
